## Module <base_account_budget>

#### 13.1009.2025
#### Version 19.0.1.0.0
#### ADD
- Initial commit for Budget Management
